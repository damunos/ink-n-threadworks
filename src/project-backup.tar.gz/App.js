import React from "react";
import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Design from "./pages/Design";
import Admin from "./pages/Admin";
import Products from "./pages/Products";
import About from "./pages/About";
import Layout from "./components/Layout";

const App = () => {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/design" element={<Design />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/products" element={<Products />} />
        <Route path="/about" element={<About />} />
        {/* Add other routes here if needed */}
      </Routes>
    </Layout>
  );
};

export default App;