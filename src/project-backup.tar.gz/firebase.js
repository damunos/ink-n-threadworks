import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore"; // Add Firestore if needed

const firebaseConfig = {
  apiKey: "AIzaSyDDCoClVk2jxfY5r_Vtxyp9QBi01iT99Xw",
  authDomain: "ink-n-threadworks.firebaseapp.com",
  projectId: "ink-n-threadworks",
  storageBucket: "ink-n-threadworks.firebasestorage.app",
  messagingSenderId: "625674544596",
  appId: "1:625674544596:web:379406cf3cf61492b1e241",
  measurementId: "G-45CM8L4D1R"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
const db = getFirestore(app); // Initialize Firestore if needed

export { auth, googleProvider, db }; // Ensure db is exported if used