import React from "react";

const Products = () => {
  return (
    <div>
      <h1>Products</h1>
      <p>View our products here.</p>
    </div>
  );
};

export default Products;