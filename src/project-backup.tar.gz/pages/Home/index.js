import React from "react";

const Home = () => {
  return (
    <div>
      <h1>Welcome to Ink N Threadworks</h1>
      <p>Your one-stop shop for custom apparel and accessories.</p>
    </div>
  );
};

export default Home;