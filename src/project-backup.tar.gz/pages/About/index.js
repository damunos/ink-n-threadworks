import React from "react";

const About = () => {
  return (
    <div>
      <h1>About Us</h1>
      <p>Learn more about Ink N Threadworks.</p>
    </div>
  );
};

export default About;