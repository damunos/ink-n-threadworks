import React, { useState } from "react";
import ColorPicker from "../../components/DesignTool/ColorPicker";
import ImageUploader from "../../components/DesignTool/ImageUploader";
import TextEditor from "../../components/DesignTool/TextEditor";
import Preview from "../../components/DesignTool/Preview";
import StockArtLibrary from "../../components/DesignTool/StockArtLibrary";
import "./Design.css";

const Design = () => {
  const [selectedColor, setSelectedColor] = useState("#ffffff");
  const [uploadedImages, setUploadedImages] = useState([]);
  const [selectedStockArt, setSelectedStockArt] = useState(null);
  const [text, setText] = useState("");
  const [textColor, setTextColor] = useState("#000000");
  const [font, setFont] = useState("Arial");
  const [imageSize, setImageSize] = useState(100);

  const handleImageUpload = (image) => {
    setUploadedImages([...uploadedImages, image]);
  };

  const handleStockArtSelect = (image) => {
    setSelectedStockArt(image);
  };

  const handleTextChange = (newText) => {
    setText(newText);
  };

  const handleTextColorChange = (color) => {
    setTextColor(color);
  };

  const handleFontChange = (font) => {
    setFont(font);
  };

  const handleColorChange = (color) => {
    setSelectedColor(color);
  };

  const handleImageResize = (size) => {
    setImageSize(size);
  };

  return (
    <div className="design-page">
      <div className="design-tools">
        <ColorPicker color={selectedColor} setColor={handleColorChange} />
        <ImageUploader onImageUpload={handleImageUpload} onImageResize={handleImageResize} />
        <StockArtLibrary onSelect={handleStockArtSelect} />
        <TextEditor
          onTextChange={handleTextChange}
          onTextColorChange={handleTextColorChange}
          onFontChange={handleFontChange}
        />
      </div>
      <div className="preview-section">
        <div className="preview-text">
          <h2>Preview</h2>
        </div>
        <Preview
          selectedColor={selectedColor}
          uploadedImages={uploadedImages}
          selectedStockArt={selectedStockArt}
          text={text}
          textColor={textColor}
          font={font}
          imageSize={imageSize}
        />
      </div>
    </div>
  );
};

export default Design;