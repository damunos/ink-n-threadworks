import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { db } from "../../firebase"; // Ensure the import path is correct
import { collection, getDocs } from "firebase/firestore";
import Button from "../ui/Button";

const ProductList = ({ setSelectedProduct }) => {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [color, setColor] = useState("");
  const [price, setPrice] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "products"));
        const productList = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setProducts(productList);
      } catch (error) {
        console.error("Error fetching products: ", error);
      }
    };

    fetchProducts();
  }, []);

  const filteredProducts = products
    .filter((product) => product.PRODUCT_TITLE?.toLowerCase().includes(search.toLowerCase()))
    .filter((product) => (category ? product.CATEGORY_NAME === category : true))
    .filter((product) => (color ? product.COLOR_NAME === color : true))
    .filter((product) => (price ? parseFloat(product.MSRP) <= parseFloat(price) : true));

  return (
    <div className="p-6">
      <Button onClick={() => navigate("/")} className="bg-gray-700 text-white px-4 py-2 mb-4">
        Home
      </Button>

      <h2 className="text-2xl font-semibold">Select a Product</h2>

      <input
        type="text"
        placeholder="Search for a product..."
        className="border p-2 w-full mt-2"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <select value={category} onChange={(e) => setCategory(e.target.value)} className="border p-2 w-full mt-2">
        <option value="">All Categories</option>
        {Array.from(new Set(products.map((product) => product.CATEGORY_NAME))).map((category) => (
          <option key={category} value={category}>
            {category}
          </option>
        ))}
      </select>

      <select value={color} onChange={(e) => setColor(e.target.value)} className="border p-2 w-full mt-2">
        <option value="">All Colors</option>
        {Array.from(new Set(products.map((product) => product.COLOR_NAME))).map((color) => (
          <option key={color} value={color}>
            {color}
          </option>
        ))}
      </select>

      <input
        type="number"
        placeholder="Max Price"
        className="border p-2 w-full mt-2"
        value={price}
        onChange={(e) => setPrice(e.target.value)}
      />

      <div className="grid grid-cols-3 gap-4 mt-4">
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            className="border p-4 rounded-lg shadow-md cursor-pointer"
            onClick={() => {
              setSelectedProduct(product);
              navigate("/design");
            }}
          >
            <img
              src={product.THUMBNAIL_IMAGE}
              alt={product.PRODUCT_TITLE}
              className="h-32 w-auto mx-auto"
            />
            <h3 className="text-lg font-bold text-center">{product.PRODUCT_TITLE}</h3>
            <p className="text-center">${product.MSRP}</p>
            <Button
              onClick={() => {
                setSelectedProduct(product);
                navigate("/design");
              }}
              className="mt-2 bg-gray-700 text-white px-4 py-2 w-full"
            >
              Select
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductList;