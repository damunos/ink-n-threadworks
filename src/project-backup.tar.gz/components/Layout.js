import React from "react";
import Header from "./Header";
import NavBar from "./NavBar";
import "./Layout.css";

const Layout = ({ children }) => {
  return (
    <div>
      <Header />
      <NavBar />
      <main>
        {children}
      </main>
    </div>
  );
};

export default Layout;