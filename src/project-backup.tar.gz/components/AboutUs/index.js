import React from "react";

const AboutUs = () => {
  return (
    <div>
      <h1>About Us</h1>
      {/* Add about us components here */}
    </div>
  );
};

export default AboutUs;